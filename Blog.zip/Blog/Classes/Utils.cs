﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Blog.Classes
{
    public class Utils
    {
        public static string CutText(string text, int maxLenth = 400)
        {
            if (text == null || text.Length <= maxLenth)
            {
                return text;
            }
            var shortText = text.Substring(0, maxLenth) + "...";

            return shortText;
        }
    }
}