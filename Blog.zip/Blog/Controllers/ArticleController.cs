﻿using Blog.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using PagedList;
using PagedList.Mvc;
using Blog.Controllers;
using Microsoft.AspNet.Identity.EntityFramework;

namespace Blog.Controllers
{
    public class ArticleController : Controller
    {
       // private BlogDbContext db = new BlogDbContext();

        // GET: Article
        public ActionResult Index()
        {
            //var items = for item in db.Articles select item;
            
            //return (View(items.ToPagedList(pageNumber: page ?? 1, pageSize: 10)));
           
            return View();
        }
        //db.Articles.Include(p => p.Author).ToList().ToPagedList(page ?? 1, 3)

        public ActionResult List(int? page, string searchString)
        {
            using (var database = new BlogDbContext())
            {
                var articles = database.Articles
                .Include(a => a.Author)
                .Include(a => a.Tags)
                .ToList();

                var articls = from s in database.Articles
                            select s;

                if (!String.IsNullOrEmpty(searchString))
                {
                    articls = articls.Where(s => s.Title.Contains(searchString) || s.Content.Contains(searchString));
                    return View(articls.Include(p => p.Author).OrderByDescending(b => b.Date).ToList().ToPagedList(page ?? 1, 3));
                }

                return View(articles.ToPagedList(page ?? 1, 3));
            }
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            using (var database = new BlogDbContext())
            {
                var article = database.Articles
                .Where(a => a.Id == id)
                .Include(a => a.Author)
                .Include(a => a.Tags)
                .First();

                if (article == null)
                {
                    return HttpNotFound();
                }
                return View(article);
            }
        }


        // Get Method
        [HttpGet]
        [Authorize]
        [ValidateInput(false)]
        public ActionResult Create()
        {
            using (var db = new BlogDbContext())
            {
                var model = new ArticleViewModel();
                model.Categories = db.Categories.ToList();
                return View(model);
                
            }
        }

        [HttpPost]
        [Authorize]
        [ValidateInput(false)]
        public ActionResult Create(ArticleViewModel model)
        {
            using (var db = new BlogDbContext())
            {
                var user = db.Users.FirstOrDefault(u => u.UserName.Equals(this.User.Identity.Name));

                var article = new Article(user.Id, model.Title, model.Content, model.CategoryId, model.Date);

                this.SetArticleTags(article, model, db);

                db.Articles.Add(article);
                db.SaveChanges();

                return RedirectToAction("List");
            }
        }

        [Authorize]
        [ValidateInput(false)]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            using (var db = new BlogDbContext())
            {
                // Get article from database
                var article = db.Articles.FirstOrDefault(a => a.Id == id);

                if (!this.IsAuthorizedToEdit(article))
                {
                    return new HttpStatusCodeResult(HttpStatusCode.Forbidden);
                }
                if (article == null)
                {
                    return HttpNotFound();
                }

                var model = new ArticleViewModel();
                model.AuthorId = article.AuthorId;
                model.Title = article.Title;
                model.Content = article.Content;
                model.CategoryId = article.CategoryId;
                model.Categories = db.Categories.OrderBy(c => c.Name).ToList();
                model.Tags = string.Join(", ", article.Tags.Select(t => t.Name));

                return View(model);
            }
        }        

        [HttpPost]
        [Authorize]
        [ValidateInput(false)]
        public ActionResult Edit(int? id, ArticleViewModel model)
        {
            if (ModelState.IsValid)
            {
                using (var db = new BlogDbContext())
                {
                    var article = db.Articles.FirstOrDefault(a => a.Id == id);
                    article.Title = model.Title;
                    article.Content = model.Content;
                    article.CategoryId = model.CategoryId;
                    this.SetArticleTags(article, model, db);

                    db.Entry(article).State = EntityState.Modified;
                    db.SaveChanges();

                    return RedirectToAction("List");
                }
            }
            return View(model);
        }

        [Authorize]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            using (var db = new BlogDbContext())
            {
                // Get article from database
                var article = db.Articles                    
                    .Include(a => a.Author)
                    .Include(a => a.Category)
                    .Include(a => a.Tags)
                    .FirstOrDefault(a => a.Id == id);

                ViewBag.Tags = string.Join(", ", article.Tags.Select(t => t.Name));

                // Check if article exists
                if (article == null)
                {
                    return HttpNotFound();
                }
                return View(article);
            }
        }

        [HttpPost]
        [Authorize]
        [ActionName("Delete")]
        public ActionResult DeleteConfirmed(int? id)
        {
            using (var db = new BlogDbContext())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                var article = db.Articles.FirstOrDefault(a => a.Id == id);

                db.Articles.Remove(article);
                db.SaveChanges();

                if (article == null)
                {
                    return HttpNotFound();
                }
                return RedirectToAction("List");
            }

        }

        private void SetArticleTags(Article article, ArticleViewModel model, BlogDbContext db)
        {
            // Split tags
            var tagsStrings = model.Tags
                .Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(t => t.ToLower())
                .Distinct();

            // Clear all current article tags
            article.Tags.Clear();

            // Set new article tags
            foreach (var tagString in tagsStrings)
            {
                // Get tag from db by its name
                Tag tag = db.Tags.FirstOrDefault(t => t.Name.Equals(tagString));
                
                // If the tag is null, create new tag
                if (tag == null)
                {
                    tag = new Tag() { Name = tagString };
                    db.Tags.Add(tag);
                }

                // Add tag to article tags
                article.Tags.Add(tag);
            }
        }

        private bool IsAuthorizedToEdit(Article article)
        {
            bool isAuthor = article.IsUserAuthor(User.Identity.Name);
            bool isAdmin = User.IsInRole("Admin");

            return isAdmin || isAuthor;
        }
    }
}